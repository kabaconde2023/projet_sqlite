class User {
  String? civilite;
  String nom;
  String prenom;
  String? specialite;
  List<String> matieres;

  User({
    this.civilite,
    required this.nom,
    required this.prenom,
    this.specialite,
    required this.matieres,
  });

  factory User.fromJson(Map<String, dynamic> json) {
    return User(
      civilite: json['civilite'],
      nom: json['nom'],
      prenom: json['prenom'],
      specialite: json['specialite'],
      matieres: List<String>.from(json['matieres']),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'civilite': civilite,
      'nom': nom,
      'prenom': prenom,
      'specialite': specialite,
      'matieres': matieres,
    };
  }
}
