import 'dart:convert';
import 'dart:io';
import 'package:path_provider/path_provider.dart';
import 'user.dart'; // Import the User class

class DataManager {
  Future<String> get _localPath async {
    final directory = await getApplicationDocumentsDirectory();
    return directory.path;
  }

  Future<File> get _localFile async {
    final path = await _localPath;
    return File('$path/user_data.json');
  }

  Future<void> saveUserData(List<User> users) async {
    final file = await _localFile;
    List<User> existingUsers = [];

    try {
      final jsonString = await file.readAsString();
      final jsonData = jsonDecode(jsonString) as List;
      existingUsers = jsonData.map((data) => User.fromJson(data)).toList();
    } catch (e) {
      // Handle any errors when reading the existing data.
    }

    // Merge the existing users with the new users.
    existingUsers.addAll(users);

    // Convert the merged list to JSON and write it to the file.
    final jsonData = existingUsers.map((user) => user.toJson()).toList();
    await file.writeAsString(jsonEncode(jsonData));
  }


  Future<List<User>?> loadUserData() async {
    try {
      final file = await _localFile;
      if (!file.existsSync()) {
        return null;
      }

      final jsonString = await file.readAsString();
      print('Loaded JSON data: $jsonString'); // Add this line to check the loaded data.
      final jsonData = jsonDecode(jsonString) as List;
      return jsonData.map((data) => User.fromJson(data)).toList();
    } catch (e) {
      print('Error loading user data: $e'); // Add this line to check for errors.
      return null;
    }
  }

}
