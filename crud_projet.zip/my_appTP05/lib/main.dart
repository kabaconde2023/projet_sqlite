import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'user.dart'; // Import the User class
import 'display_page.dart'; // Import the DisplayPage widget
import 'globals.dart'; // Import the global variables
import 'data_manager.dart'; // Import the DataManager class

void main() async {
  WidgetsFlutterBinding.ensureInitialized(); // Initialize Flutter binding.

  final loadedUsers = await DataManager().loadUserData();

  if (loadedUsers != null) {
    globalUsers = loadedUsers;
  } else {
    print('No user data loaded or an error occurred.');
  }

  runApp(MyApp());
}




class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: MyForm(),
    );
  }
}

class MyForm extends StatefulWidget {
  @override
  _MyFormState createState() => _MyFormState();
}

class _MyFormState extends State<MyForm> {
  String? civilite;
  String nom = "";
  String prenom = "";
  String? specialite;
  List<String> matieres = [];

  // Liste de matières en mémoire (à remplir selon vos besoins)
  List<String> matieresEnMemoire = ["Mathématiques", "Physique", "Chimie", "Informatique"];
  List<String> specialitesEnMemoire = ["Informatique", "Electrique", "Spécialité 4"];
  User? editingUser; // Track the user being edited
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Formulaire Flutter'),
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16.0),
        child: Column(
          children: <Widget>[
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: ["M.", "Mme", "Mlle"].map<Widget>((String value) {
                return Row(
                  children: [
                    Radio<String>(
                      value: value,
                      groupValue: civilite,
                      onChanged: (String? newValue) {
                        setState(() {
                          civilite = newValue;
                        });
                      },
                    ),
                    Text(value),
                  ],
                );
              }).toList(),
            ),
            TextFormField(
              decoration: InputDecoration(labelText: 'Nom'),
              onChanged: (value) {
                setState(() {
                  nom = value;
                });
              },
            ),
            TextFormField(
              decoration: InputDecoration(labelText: 'Prénom'),
              onChanged: (value) {
                setState(() {
                  prenom = value;
                });
              },
            ),
            DropdownButtonFormField<String>(
              value: specialite,
              decoration: InputDecoration(labelText: 'Spécialité'),
              onChanged: (String? value) {
                setState(() {
                  specialite = value; // Update the 'specialite' variable
                });
              },
              items: specialitesEnMemoire.map((String specialite) {
                return DropdownMenuItem<String>(
                  value: specialite,
                  child: Text(specialite),
                );
              }).toList(),
            ),
            SizedBox(height: 16.0),
            Text('Sélectionnez les matières :'),
            Column(
              children: matieresEnMemoire.map((String matiere) {
                return CheckboxListTile(
                  title: Text(matiere),
                  value: matieres.contains(matiere),
                  onChanged: (bool? value) {
                    setState(() {
                      if (value != null) {
                        if (value) {
                          matieres.add(matiere);
                        } else {
                          matieres.remove(matiere);
                        }
                      }
                    });
                  },
                );
              }).toList(),
            ),
            SizedBox(height: 16.0),
            ElevatedButton(
              onPressed: () async {
                // Create or update a User object
                User newUser = User(
                  civilite: civilite,
                  nom: nom,
                  prenom: prenom,
                  specialite: specialite,
                  matieres: List<String>.from(matieres),
                );

                if (editingUser == null) {
                  // Create a new user
                  globalUsers.add(newUser);
                } else {
                  // Update the existing user
                  int index = globalUsers.indexOf(editingUser!);
                  globalUsers[index] = newUser;
                  editingUser = null; // Reset editing state
                }

                // Clear the form fields
                setState(() {
                  civilite = null;
                  nom = "";
                  prenom = "";
                  specialite = null;
                  matieres.clear();
                });

                // Save the user data to the JSON file
                await DataManager().saveUserData(globalUsers);
              },
              child: Text(editingUser == null ? 'Enregistrer' : 'Modifier'),
            ),

            ElevatedButton(
              onPressed: () {
                // Navigate to the DisplayPage and pass the globalUsers list
                Navigator.of(context).push(
                  MaterialPageRoute(
                    builder: (context) => DisplayPage(
                      globalUsers,
                      onEdit: (user) {
                        // Set the user for editing when Edit is pressed in DisplayPage
                        setState(() {
                          editingUser = user;
                          civilite = user.civilite;
                          nom = user.nom;
                          prenom = user.prenom;
                          specialite = user.specialite;
                          matieres = List<String>.from(user.matieres);
                        });
                      },
                    ),
                  ),
                );
              },
              child: Text('Afficher Utilisateurs'),
            ),
          ],
        ),
      ),
    );
  }
}
